                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2305359
Google AIY Voice Kit Case by major_tomm is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Update: I've added a version with Hexagon cutouts!

A case to replace the cardboard box supplied with the Google AIY Voice Kit. Suitable for Raspberry Pi 0, 0W, 2 and 3!

I'd advise trimming down the pins on the microphone extension board so they aren't so proud. A little doublesided tape will then let you affix it to the lid!

https://www.youtube.com/watch?v=qoGTWS-7Lcg&feature=youtu.be

# Print Settings

Printer Brand: 3D Systems
Printer: CubePro
Rafts: Yes
Supports: No
Resolution: 200

Notes: 
I'd suggest a raft for the base as mine lifted ever so slightly. If you print the lid upside-down and the base right-way-up you shouldn't need supports.